from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired
from flask import Flask, url_for, request, render_template
import json
class AddworkForm(FlaskForm):
    title = StringField('Автор проезведения', validators=[DataRequired()])
    content = TextAreaField('текст проезведения', validators=[DataRequired()])
    submit = SubmitField('Добавить')
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route('/', methods=['POST', 'GET'])
@app.route('/add_news', methods=['GET', 'POST'])
def add_news():
    form = AddworkForm()
    return render_template('add_news.html', title='Авторизация', form=form)
if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')