from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField, BooleanField
from wtforms.validators import DataRequired
 
class main(FlaskForm):
    username = StringField('логин')
    password = PasswordField('пароль')
    remember_me = BooleanField('запомни меня')
    submit = SubmitField('изменить')