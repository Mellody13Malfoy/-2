from flask_wtf import FlaskForm
from db import DB, UserModel, newsModel
from main import main
from forma import Form
from wtforms import StringField, SubmitField, TextAreaField
from wtforms.validators import DataRequired
from flask import Flask, url_for, request, render_template, redirect, session
from LoginForm import LoginForm
from add_work import AddworkForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

db = DB()
newsModel(db.get_connection()).init_table()
UserModel(db.get_connection()).init_table()

@app.route('/login', methods=['POST', 'GET'])
def login():
    form = LoginForm()
    err = ''
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data
        user_model = UserModel(db.get_connection())
        exists = user_model.exists(user_name, password)
        if user_name == 'admin':
            session['username'] = user_name
            session['user_id'] = exists[1]
            return redirect("/index1")
        if (exists[0]):
            session['username'] = user_name
            session['user_id'] = exists[1]
            return redirect("/index")        
        else:
            err = 'такого пользователя нет, зарегестрируйтесь'
    return render_template('login.html', title='Авторизация', form=form, err=err)

@app.route('/regi', methods=['POST', 'GET'])
def regi():
    form = Form()
    if form.validate_on_submit():
        user_name = form.username.data
        password = form.password.data
        user_model = UserModel(db.get_connection())
        exists = user_model.exists(user_name, password)
        UserModel(db.get_connection()).insert(user_name, password)
        return redirect("/login")
    return render_template('regi.html', title='Авторизация', form=form)

@app.route('/logout')
def logout():
    session.pop('username',0)
    session.pop('user_id',0)
    return redirect('/login')

@app.route('/')
@app.route('/index1')
def index1():
    if 'username' not in session:
        return redirect('/login')
    news = newsModel(db.get_connection()).get_all()
    return render_template('index1.html', username=session['username'], news=news)

@app.route('/')
@app.route('/index')
def index():
    if 'username' not in session:
        return redirect('/login')
    news = newsModel(db.get_connection()).get_all(session['user_id'])
    return render_template('index.html', username=session['username'], news=news)

@app.route('/add_story', methods=['GET', 'POST'])
def add_stiry():
    if 'username' not in session:
        return redirect('/login')
    form = AddworkForm()
    if form.validate_on_submit():
        title = form.title.data
        content = form.content.data
        nm = newsModel(db.get_connection())
        nm.insert(title,content,session['user_id'])
        return redirect("/index")
    return render_template('add_news.html', title='Добавление проезведение',
                           form=form, username=session['username'])

@app.route('/open_story/<int:news_id>', methods=['GET'])
def open_story(news_id):
    print(news_id)
    if 'username' not in session:
        return redirect('/login')
    form = AddworkForm()
    nm = newsModel(db.get_connection())#подключились к базе
    print(nm.get(news_id))
    title = nm.get(news_id)[1]
    content = nm.get(news_id)[2]
    return render_template('open_story.html', title=title, content=content)

@app.route('/deletestory/<int:news_id>', methods=['GET'])
def deletestory(news_id):
    print(news_id)
    if 'username' not in session:
        return redirect('/login')
    nm = newsModel(db.get_connection())
    nm.delete(news_id)
    return redirect("/index1")        
 
@app.route('/delete_story/<int:news_id>', methods=['GET'])
def delete_story(news_id):
    print(news_id)
    if 'username' not in session:
        return redirect('/login')
    nm = newsModel(db.get_connection())
    nm.delete(news_id)
    return redirect("/index")

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
